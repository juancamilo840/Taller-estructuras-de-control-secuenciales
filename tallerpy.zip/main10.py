"""
Entradas
sueldo_bruto-->float-->sueldo_bruto
salida
sueldo_neto-->float-->sueldo_neto
"""
sueldo_bruto=float(input)("Digite salario bruto"))
sueldo_neto=0.0#float
if(sueldo_bruto>=5_000_000):
  sueldo_neto=sueldo_bruttto*0.10+sueldo_bruto