if __name__ == '__main__':
	print("Ingrese el valor de a:")
	a = input()
	print("Ingrese el valor de b:")
	b = input()
	print("Ingrese el valor de c:")
	c = input()
	print("Ingrese el valor de d:")
	d = input()
	if a>b:
		if a>c:
			if a>d:
				print("Datos: ",a,"",b,"",c,"",d)
			else:
				print("Datos: ",a,"",d,"",c,"",b)