if __name__ == '__main__':
	edad1 = float(input())
	edad2 = float(input())
	edad3 = float(input())
	p = (edad1+edad2+edad3)/3
	print("el promedio es",p)
