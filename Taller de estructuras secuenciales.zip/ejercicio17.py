	print("Ingrese el presupuesto")
	presupuesto = float(input())
	a_ginecoloia = presupuesto*0.40
	a_traumatologia = presupuesto*0.30
	a_pediatria = presupuesto*0.30
	print("En el area de ginecologia:",a_ginecoloia)
	print("En el area de traumatologia:",a_traumatologia)
	print("En el area de pediatria:",a_pediatria)