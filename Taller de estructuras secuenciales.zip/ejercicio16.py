	print("Ingrese los galones que va a comprar")
	galon = float(input())
	print("cada galon tiene 3.785 litros")
	print("cada galon vale 50 mil")
	costo = galon*50.000
	print("usted compro:",costo,"galon")