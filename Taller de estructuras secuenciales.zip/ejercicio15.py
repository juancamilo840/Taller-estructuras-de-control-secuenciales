	print("Ingrese el precio del producto:")
	precio = float(input())
	print("Ingrese la cantidad de productos a comprar:")
	cantidad = float(input())
	print("Ingrese su Precio de venta al publico:")
	pvp = float(input())
	compra = precio*cantidad*pvp
	print("el total a pagar es:",compra)