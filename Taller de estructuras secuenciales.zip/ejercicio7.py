# 1 metro a pies = 12
# 1 metro a pulgadas = 39.27
	metro = float()
	pulgada = float()
	pies = float()
	print("Escribe los metros")
	metro = float(input())
	pulgada = metro*39.27
	pies = metro*12
	print(metro,"metros convertidos a pulgadas es: ",pulgada)
	print(metro,"metros convertidos a pies es: ",pies)