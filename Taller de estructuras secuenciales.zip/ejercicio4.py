	print "Ingrese el total de la compra"
	tc = float(raw_input())
	descuento = tc*0.15
	total_pagar = tc-descuento
	print "Su total a pagar es: ",total_pagar