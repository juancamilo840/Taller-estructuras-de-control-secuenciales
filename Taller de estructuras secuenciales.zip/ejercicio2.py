	capital = float()
	ganancia = float()
	print("Escribe el capital a invertir")
	capital = float(input())
	ganancia = capital*.02
	print("La ganancia obtenida por el capital invertido es: $",ganancia)
	print("La ganancia total con el capital invertido es: $",capital+ganancia)
